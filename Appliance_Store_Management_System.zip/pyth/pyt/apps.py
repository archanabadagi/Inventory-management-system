from django.apps import AppConfig


class PytConfig(AppConfig):
    name = 'pyt'
